#!/bin/bash

cd target
java -jar standalone.jar
